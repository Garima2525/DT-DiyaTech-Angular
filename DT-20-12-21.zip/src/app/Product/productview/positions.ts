export const positions = [
    'CEO',
    'Chief Technical Officer',
    'VP, Engineering',
    'Team Lead',
    'Director, Engineering',
    'Software Architect',
    'Software Developer',
    'Junior Software Developer'
];