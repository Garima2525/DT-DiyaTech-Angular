import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-person-view',
  templateUrl: './sales-person-view.component.html',
  styleUrls: ['./sales-person-view.component.css']
})
export class SalesPersonViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
