import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rolepermission',
  templateUrl: './rolepermission.component.html',
  styleUrls: ['./rolepermission.component.css']
})
export class RolepermissionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
